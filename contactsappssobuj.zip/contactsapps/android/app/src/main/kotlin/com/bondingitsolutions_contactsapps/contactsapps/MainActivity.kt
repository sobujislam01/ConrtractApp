package com.bondingitsolutions_contactsapps.contactsapps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
